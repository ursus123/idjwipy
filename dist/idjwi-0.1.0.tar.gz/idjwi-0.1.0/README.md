This project is about facilitating 
repetitive and common business analytics tasks
The project is under construction.

Key areas covered by this library:
 - opening data
 - data manipulation
 - exploratory data analysis
 - pre-modeling, machine learning
 - reporting